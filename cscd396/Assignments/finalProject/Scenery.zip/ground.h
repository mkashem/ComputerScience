#include <stdio.h>
#include <GL/glew.h>

extern GLuint ground_vao;
extern GLuint ground_vbo;

void createGround();

void renderGround();

