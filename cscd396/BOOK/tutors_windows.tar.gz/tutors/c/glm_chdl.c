#if defined(WINDOWS)
#include <windows.h>
#endif
#include <glm.h>
#include <ch.h>

EXPORTCH GLfloat glmUnitize_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;
    GLfloat retval;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    retval = glmUnitize(model);
    Ch_VaEnd(interp, ap);
    return retval;
}

EXPORTCH void glmDimensions_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;
    GLfloat* dimensions;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    dimensions = Ch_VaArg(interp, ap, GLfloat*);
    glmDimensions(model, dimensions);
    Ch_VaEnd(interp, ap);
}

EXPORTCH void glmScale_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;
    GLfloat scale;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    scale = Ch_VaArg(interp, ap, GLfloat);
    glmScale(model, scale);
    Ch_VaEnd(interp, ap);
}

EXPORTCH void glmReverseWinding_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    glmReverseWinding(model);
    Ch_VaEnd(interp, ap);
}

EXPORTCH void glmFacetNormals_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    glmFacetNormals(model);
    Ch_VaEnd(interp, ap);
}

EXPORTCH void glmVertexNormals_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;
    GLfloat angle;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    angle = Ch_VaArg(interp, ap, GLfloat);
    glmVertexNormals(model, angle);
    Ch_VaEnd(interp, ap);
}

EXPORTCH void glmLinearTexture_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    glmLinearTexture(model);
    Ch_VaEnd(interp, ap);
}

EXPORTCH void glmSpheremapTexture_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    glmSpheremapTexture(model);
    Ch_VaEnd(interp, ap);
}

EXPORTCH void glmDelete_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    glmDelete(model);
    Ch_VaEnd(interp, ap);
}

EXPORTCH GLMmodel* glmReadOBJ_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    char* filename;
    GLMmodel* retval;

    Ch_VaStart(interp, ap, varg);
    filename = Ch_VaArg(interp, ap, char* );
    retval = glmReadOBJ(filename);
    Ch_VaEnd(interp, ap);
    return retval;
}

EXPORTCH void glmWriteOBJ_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;
    char* filename;
    GLuint mode;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    filename = Ch_VaArg(interp, ap, char*);
    mode = Ch_VaArg(interp, ap, GLuint);
    glmWriteOBJ(model, filename, mode);
    Ch_VaEnd(interp, ap);
}

EXPORTCH void glmDraw_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;
    GLuint mode;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    mode = Ch_VaArg(interp, ap, GLuint);
    glmDraw(model, mode);
    Ch_VaEnd(interp, ap);
}

EXPORTCH GLuint glmList_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;
    GLuint mode;
    GLuint retval;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    mode = Ch_VaArg(interp, ap, GLuint);
    retval = glmList(model, mode);
    Ch_VaEnd(interp, ap);
    return retval;
}

EXPORTCH void glmWeld_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    GLMmodel* model;
    GLfloat epsilon;

    Ch_VaStart(interp, ap, varg);
    model = Ch_VaArg(interp, ap, GLMmodel*);
    epsilon = Ch_VaArg(interp, ap, GLfloat);
    glmWeld(model, epsilon);
    Ch_VaEnd(interp, ap);
}

EXPORTCH GLubyte* glmReadPPM_chdl(void *varg) {
    ChInterp_t interp;
    va_list ap;
    char* filename;
    int* width;
    int* height;
    GLubyte* retval;

    Ch_VaStart(interp, ap, varg);
    filename = Ch_VaArg(interp, ap, char* );
    width = Ch_VaArg(interp, ap, int*);
    height = Ch_VaArg(interp, ap, int*);
    retval = glmReadPPM(filename, width, height);
    Ch_VaEnd(interp, ap);
    return retval;
}
